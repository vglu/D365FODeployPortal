PARAM (
    [Parameter(Mandatory=$true)]
    $log,
    [Parameter(Mandatory=$true)]
    $packagesLocalDirectoryPath
)

###########################################################
# Rename as "bak"
###########################################################
function Rename-FileAsBak([string] $filePath)
{    
    if ($filePath -ne $null -and [System.IO.File]::Exists($filePath))
    {
        [string] $directory = [System.IO.Path]::GetDirectoryName($filePath);
        [string] $newName = "$([System.IO.Path]::GetFileName($filePath)).bak";
        [string] $newFilePath = [System.IO.Path]::Combine($directory, $newName);

        # Delete any existing bak file
        if (Test-Path -Path $newFilePath)
        {
            Remove-Item -Path $newFilePath -Force;
        }

        # Rename the file with ".bak" extension
        Rename-Item -Path $filePath -NewName $newName -Force
        Write-Log "File renamed to: $newFilePath .";
    }
}

function Get-FileVersionSafe([string]$path)
{
    $versionTmp = Get-FileVersion($path); 
    if ($versionTmp)
    {
        return [Version]::new($versionTmp);
    }
    return [Version]::new(0,0,0,0);
}

###########################################################
# Compares versions of given assemblies with stored in system and replaces older
###########################################################
function Restore-LatestVersions([string]$packageBinPath, [string]$binariesStorageName, [string[]]$modulesNames, [string[]]$assemblies)
{    
    $PackagesLocalDirectoryBinPath = [System.IO.Path]::Combine($packageBinPath, "bin", $binariesStorageName);

    if (!(Test-Path $PackagesLocalDirectoryBinPath))
    {
        New-Item -ItemType Directory -Force -Path $PackagesLocalDirectoryBinPath
    }

    [string[]]$PackagesLocalDirectoryModulesPaths = @();
    foreach($name in $modulesNames)
    {
        $PackagesLocalDirectoryModulesPaths += $([System.IO.Path]::Combine($packageBinPath, $name, "bin", "*"));
    }

    $latestExt = ".latest";
    
    # search for the assembly in the modules bin folders
    $filesFound = Get-ChildItem -File -Include $assemblies -Path $PackagesLocalDirectoryModulesPaths
    foreach ($fileInfo in $filesFound)
    {
        $fileVersionInModuleBin = Get-FileVersionSafe($fileInfo.FullName)
        $filePathInPackageBin = [System.IO.Path]::Combine($PackagesLocalDirectoryBinPath, $($fileInfo.Name + $latestExt));
        $fileVersionInPackageBin = Get-FileVersionSafe($filePathInPackageBin); 
        if ($fileVersionInPackageBin -gt $fileVersionInModuleBin)
        {
            # Versions are different, so rename the assembly we shipped to *.bak then copy newer version from package bin
            Write-Log "File in module bin have lesser version than in package bin: $($fileInfo.FullName) version: '$fileVersionInModuleBin' vs '$fileVersionInPackageBin'.";
            Rename-FileAsBak($fileInfo.FullName);
            Copy-Item $filePathInPackageBin -Destination $fileInfo.FullName -Force
        }
        elseif ($fileVersionInModuleBin -gt $fileVersionInPackageBin)
        {
            # Versions are different, so rename the assembly we stored in package bin to *.bak then copy newer version from module bin
            Write-Log "File in package bin have lesser version than in module bin: $($filePathInPackageBin) version: '$fileVersionInPackageBin' vs '$fileVersionInModuleBin'.";
            Rename-FileAsBak($filePathInPackageBin);
            Copy-Item $fileInfo.FullName -Destination $filePathInPackageBin -Force
        }
        else 
        { 
            # Versions are the same                        
            Write-Log "File in package bin have same version with module bin: '$($fileInfo.Name)' - '$fileVersionInPackageBin' and '$fileVersionInModuleBin'.";                         
        }  
    }
}

# Import the AosCommon module and initialize the log
Import-Module "$PSScriptRoot\AosCommon.psm1" -Force -DisableNameChecking
Initialize-Log $log

$ModulesNames = @("ElectronicReporting", "TaxEngine");
$StorageName = "BinariesStorage";
Write-Log "Checking '$($ModulesNames -join ', ')' assemblies versions."

try
{
	$error.Clear()

    if (Test-Path $packagesLocalDirectoryPath)
    {
        [string[]]$Assemblies = @(
            "Microsoft.Dynamics.ElectronicReporting.Instrumentation.dll", 
            "Microsoft.Dynamics.TaxEngine.Instrumentation.dll", 
            "Microsoft.Dynamics.AX.Framework.TaxEngine.dll",
            "Microsoft.Z3.dll", 
            "libz3.dll", 
            "Microsoft.Dynamics365.*.dll"
        );
        Restore-LatestVersions $packagesLocalDirectoryPath $StorageName $ModulesNames $Assemblies;

        Write-Log "Checking '$($ModulesNames -join ', ')' assemblies complete."
    }
    else 
    {
        Write-Log "A given directory path '$packagesLocalDirectoryPath' not found, exiting."
    }
}
catch
{
	# write the exception and that this process failed. Do not throw as this should not 
	# cause the deployment or update to fail.
    Write-Exception $_       
    Write-Log "Checking '$($ModulesNames -join ', ')' assemblies versions failed, see $log for details."
}
# SIG # Begin signature block
# MIIr5gYJKoZIhvcNAQcCoIIr1zCCK9MCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCACbJlqy9j029d5
# opt4I6Awea1tzFHlN8KoA+PNdrznZqCCEW4wggh+MIIHZqADAgECAhM2AAACAO38
# jbec3qFIAAIAAAIAMA0GCSqGSIb3DQEBCwUAMEExEzARBgoJkiaJk/IsZAEZFgNH
# QkwxEzARBgoJkiaJk/IsZAEZFgNBTUUxFTATBgNVBAMTDEFNRSBDUyBDQSAwMTAe
# Fw0yNDExMDgxMjQzMjhaFw0yNTExMDgxMjQzMjhaMCQxIjAgBgNVBAMTGU1pY3Jv
# c29mdCBBenVyZSBDb2RlIFNpZ24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEK
# AoIBAQC5L/UPrOpwYjxcoZC0TqqvMF1WUELvwXN+k27SrA5rohJknn7Cgbxg4hGT
# XKqpcdbtsVTN3ZY896SJ20uQ+INL5OVLzpW408nCNTPYg2LtGJbqHUjpNm0hLCJ+
# gO5Jn2T8DDzIJoUijGXj1m+hRLKb2nOIicCED2GuYBmuWXnaY7INmVEaU3peryty
# ZjDuxdyGDuiPURz8lW1SUiDzoszNp1oswVr+WjDvLDUx4HlxPsG8zUjIst0NnJ6o
# z4tNFKaUBDCetcMjQxpCETn29a1CuRddxZLjPHZHfcotr5sh1S6bNQdzVaMNsxV8
# L3wjHb7XJ6ZVm662mHEiPgpyNcLhAgMBAAGjggWKMIIFhjApBgkrBgEEAYI3FQoE
# HDAaMAwGCisGAQQBgjdbAQEwCgYIKwYBBQUHAwMwPQYJKwYBBAGCNxUHBDAwLgYm
# KwYBBAGCNxUIhpDjDYTVtHiE8Ys+hZvdFs6dEoFgg93NZoaUjDICAWQCAQ4wggJ2
# BggrBgEFBQcBAQSCAmgwggJkMGIGCCsGAQUFBzAChlZodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpaW5mcmEvQ2VydHMvQlkyUEtJQ1NDQTAxLkFNRS5HQkxfQU1F
# JTIwQ1MlMjBDQSUyMDAxKDIpLmNydDBSBggrBgEFBQcwAoZGaHR0cDovL2NybDEu
# YW1lLmdibC9haWEvQlkyUEtJQ1NDQTAxLkFNRS5HQkxfQU1FJTIwQ1MlMjBDQSUy
# MDAxKDIpLmNydDBSBggrBgEFBQcwAoZGaHR0cDovL2NybDIuYW1lLmdibC9haWEv
# QlkyUEtJQ1NDQTAxLkFNRS5HQkxfQU1FJTIwQ1MlMjBDQSUyMDAxKDIpLmNydDBS
# BggrBgEFBQcwAoZGaHR0cDovL2NybDMuYW1lLmdibC9haWEvQlkyUEtJQ1NDQTAx
# LkFNRS5HQkxfQU1FJTIwQ1MlMjBDQSUyMDAxKDIpLmNydDBSBggrBgEFBQcwAoZG
# aHR0cDovL2NybDQuYW1lLmdibC9haWEvQlkyUEtJQ1NDQTAxLkFNRS5HQkxfQU1F
# JTIwQ1MlMjBDQSUyMDAxKDIpLmNydDCBrQYIKwYBBQUHMAKGgaBsZGFwOi8vL0NO
# PUFNRSUyMENTJTIwQ0ElMjAwMSxDTj1BSUEsQ049UHVibGljJTIwS2V5JTIwU2Vy
# dmljZXMsQ049U2VydmljZXMsQ049Q29uZmlndXJhdGlvbixEQz1BTUUsREM9R0JM
# P2NBQ2VydGlmaWNhdGU/YmFzZT9vYmplY3RDbGFzcz1jZXJ0aWZpY2F0aW9uQXV0
# aG9yaXR5MB0GA1UdDgQWBBST/HE52ZUlmsYqZcZBdrXZ5u4ZnzAOBgNVHQ8BAf8E
# BAMCB4AwRQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEWMBQGA1UEBRMNMjM2MTY3KzUwMzE1NTCCAeYGA1UdHwSCAd0wggHZMIIB
# 1aCCAdGgggHNhj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpaW5mcmEvQ1JM
# L0FNRSUyMENTJTIwQ0ElMjAwMSgyKS5jcmyGMWh0dHA6Ly9jcmwxLmFtZS5nYmwv
# Y3JsL0FNRSUyMENTJTIwQ0ElMjAwMSgyKS5jcmyGMWh0dHA6Ly9jcmwyLmFtZS5n
# YmwvY3JsL0FNRSUyMENTJTIwQ0ElMjAwMSgyKS5jcmyGMWh0dHA6Ly9jcmwzLmFt
# ZS5nYmwvY3JsL0FNRSUyMENTJTIwQ0ElMjAwMSgyKS5jcmyGMWh0dHA6Ly9jcmw0
# LmFtZS5nYmwvY3JsL0FNRSUyMENTJTIwQ0ElMjAwMSgyKS5jcmyGgb1sZGFwOi8v
# L0NOPUFNRSUyMENTJTIwQ0ElMjAwMSgyKSxDTj1CWTJQS0lDU0NBMDEsQ049Q0RQ
# LENOPVB1YmxpYyUyMEtleSUyMFNlcnZpY2VzLENOPVNlcnZpY2VzLENOPUNvbmZp
# Z3VyYXRpb24sREM9QU1FLERDPUdCTD9jZXJ0aWZpY2F0ZVJldm9jYXRpb25MaXN0
# P2Jhc2U/b2JqZWN0Q2xhc3M9Y1JMRGlzdHJpYnV0aW9uUG9pbnQwHwYDVR0jBBgw
# FoAUllGE4Gtve/7YBqvD8oXmKa5q+dQwHwYDVR0lBBgwFgYKKwYBBAGCN1sBAQYI
# KwYBBQUHAwMwDQYJKoZIhvcNAQELBQADggEBAEDd8Wf5RkHsB64vgn2slxDtHzSo
# It9xN/Dm3RdFjNZ0diTUPMgSPYQlSk8nIAfudnB9FLavGlvZLlyUpfrPSuikepj3
# i3pqNEFn6fNdNFv/wHMxv7hQTIDCmuoR1v1rX+w3oeleBPMnN3QmH4ff1NsynyV4
# dZdYgN9Cw9sC/S3pWZpJrbOs7YOM3vqyU6DciHhC4D9i2zByHCF2pu9nYfiQf5A2
# iUZenRvyo1E5rC+UP2VZXa4k7g66W20+zAajIKKIqEmRtWahekMkCcOIHFBY4RDA
# ybgPRSGur4VDAiZPjTXS90wQXrX9CwU20cfiCC6e76F4H95KtQjKYpzuNVAwggjo
# MIIG0KADAgECAhMfAAAAUeqP9pxzDKg7AAAAAABRMA0GCSqGSIb3DQEBCwUAMDwx
# EzARBgoJkiaJk/IsZAEZFgNHQkwxEzARBgoJkiaJk/IsZAEZFgNBTUUxEDAOBgNV
# BAMTB2FtZXJvb3QwHhcNMjEwNTIxMTg0NDE0WhcNMjYwNTIxMTg1NDE0WjBBMRMw
# EQYKCZImiZPyLGQBGRYDR0JMMRMwEQYKCZImiZPyLGQBGRYDQU1FMRUwEwYDVQQD
# EwxBTUUgQ1MgQ0EgMDEwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDJ
# mlIJfQGejVbXKpcyFPoFSUllalrinfEV6JMc7i+bZDoL9rNHnHDGfJgeuRIYO1LY
# /1f4oMTrhXbSaYRCS5vGc8145WcTZG908bGDCWr4GFLc411WxA+Pv2rteAcz0eHM
# H36qTQ8L0o3XOb2n+x7KJFLokXV1s6pF/WlSXsUBXGaCIIWBXyEchv+sM9eKDsUO
# LdLTITHYJQNWkiryMSEbxqdQUTVZjEz6eLRLkofDAo8pXirIYOgM770CYOiZrcKH
# K7lYOVblx22pdNawY8Te6a2dfoCaWV1QUuazg5VHiC4p/6fksgEILptOKhx9c+ia
# piNhMrHsAYx9pUtppeaFAgMBAAGjggTcMIIE2DASBgkrBgEEAYI3FQEEBQIDAgAC
# MCMGCSsGAQQBgjcVAgQWBBQSaCRCIUfL1Gu+Mc8gpMALI38/RzAdBgNVHQ4EFgQU
# llGE4Gtve/7YBqvD8oXmKa5q+dQwggEEBgNVHSUEgfwwgfkGBysGAQUCAwUGCCsG
# AQUFBwMBBggrBgEFBQcDAgYKKwYBBAGCNxQCAQYJKwYBBAGCNxUGBgorBgEEAYI3
# CgMMBgkrBgEEAYI3FQYGCCsGAQUFBwMJBggrBgEFBQgCAgYKKwYBBAGCN0ABAQYL
# KwYBBAGCNwoDBAEGCisGAQQBgjcKAwQGCSsGAQQBgjcVBQYKKwYBBAGCNxQCAgYK
# KwYBBAGCNxQCAwYIKwYBBQUHAwMGCisGAQQBgjdbAQEGCisGAQQBgjdbAgEGCisG
# AQQBgjdbAwEGCisGAQQBgjdbBQEGCisGAQQBgjdbBAEGCisGAQQBgjdbBAIwGQYJ
# KwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMBIGA1UdEwEB/wQI
# MAYBAf8CAQAwHwYDVR0jBBgwFoAUKV5RXmSuNLnrrJwNp4x1AdEJCygwggFoBgNV
# HR8EggFfMIIBWzCCAVegggFToIIBT4YxaHR0cDovL2NybC5taWNyb3NvZnQuY29t
# L3BraWluZnJhL2NybC9hbWVyb290LmNybIYjaHR0cDovL2NybDIuYW1lLmdibC9j
# cmwvYW1lcm9vdC5jcmyGI2h0dHA6Ly9jcmwzLmFtZS5nYmwvY3JsL2FtZXJvb3Qu
# Y3JshiNodHRwOi8vY3JsMS5hbWUuZ2JsL2NybC9hbWVyb290LmNybIaBqmxkYXA6
# Ly8vQ049YW1lcm9vdCxDTj1BTUVSb290LENOPUNEUCxDTj1QdWJsaWMlMjBLZXkl
# MjBTZXJ2aWNlcyxDTj1TZXJ2aWNlcyxDTj1Db25maWd1cmF0aW9uLERDPUFNRSxE
# Qz1HQkw/Y2VydGlmaWNhdGVSZXZvY2F0aW9uTGlzdD9iYXNlP29iamVjdENsYXNz
# PWNSTERpc3RyaWJ1dGlvblBvaW50MIIBqwYIKwYBBQUHAQEEggGdMIIBmTBHBggr
# BgEFBQcwAoY7aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraWluZnJhL2NlcnRz
# L0FNRVJvb3RfYW1lcm9vdC5jcnQwNwYIKwYBBQUHMAKGK2h0dHA6Ly9jcmwyLmFt
# ZS5nYmwvYWlhL0FNRVJvb3RfYW1lcm9vdC5jcnQwNwYIKwYBBQUHMAKGK2h0dHA6
# Ly9jcmwzLmFtZS5nYmwvYWlhL0FNRVJvb3RfYW1lcm9vdC5jcnQwNwYIKwYBBQUH
# MAKGK2h0dHA6Ly9jcmwxLmFtZS5nYmwvYWlhL0FNRVJvb3RfYW1lcm9vdC5jcnQw
# gaIGCCsGAQUFBzAChoGVbGRhcDovLy9DTj1hbWVyb290LENOPUFJQSxDTj1QdWJs
# aWMlMjBLZXklMjBTZXJ2aWNlcyxDTj1TZXJ2aWNlcyxDTj1Db25maWd1cmF0aW9u
# LERDPUFNRSxEQz1HQkw/Y0FDZXJ0aWZpY2F0ZT9iYXNlP29iamVjdENsYXNzPWNl
# cnRpZmljYXRpb25BdXRob3JpdHkwDQYJKoZIhvcNAQELBQADggIBAFAQI7dPD+jf
# XtGt3vJp2pyzA/HUu8hjKaRpM3opya5G3ocprRd7vdTHb8BDfRN+AD0YEmeDB5HK
# QoG6xHPI5TXuIi5sm/LeADbV3C2q0HQOygS/VT+m1W7a/752hMIn+L4ZuyxVeSBp
# fwf7oQ4YSZPh6+ngZvBHgfBaVz4O9/wcfw91QDZnTgK9zAh9yRKKls2bziPEnxeO
# ZMVNaxyV0v152PY2xjqIafIkUjK6vY9LtVFjJXenVUAmn3WCPWNFC1YTIIHw/mD2
# cTfPy7QA1pT+GPARAKt0bKtq9aCd/Ym0b5tPbpgCiRtzyb7fbNS1dE740re0COE6
# 7YV2wbeo2sXixzvLftH8L7s9xv9wV+G22qyKt6lmKLjFK1yMw4Ni5fMabcgmzRvS
# jAcbqgp3tk4a8emaaH0rz8MuuIP+yrxtREPXSqL/C5bzMzsikuDW9xH10graZzSm
# PjilzpRfRdu20/9UQmC7eVPZ4j1WNa1oqPHfzET3ChIzJ6Q9G3NPCB+7KwX0OQmK
# yv7IDimj8U/GlsHD1z+EF/fYMf8YXG15LamaOAohsw/ywO6SYSreVW+5Y0mzJutn
# BC9Cm9ozj1+/4kqksrlhZgR/CSxhFH3BTweH8gP2FEISRtShDZbuYymynY1un+Ry
# fiK9+iVTLdD1h/SxyxDpZMtimb4CgJQlMYIZzjCCGcoCAQEwWDBBMRMwEQYKCZIm
# iZPyLGQBGRYDR0JMMRMwEQYKCZImiZPyLGQBGRYDQU1FMRUwEwYDVQQDEwxBTUUg
# Q1MgQ0EgMDECEzYAAAIA7fyNt5zeoUgAAgAAAgAwDQYJYIZIAWUDBAIBBQCgga4w
# GQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisG
# AQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIO4SYARaRWmS94R3ldH2TdKqcIFhqop3
# Mp5SSJ728J+fMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8AcwBvAGYA
# dKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEBBQAEggEA
# ay6ec5pnCAVR8Bl7soVJLpH9Li+lavusZSJx9Ki1tGU4tI2RXQDN16ejJ8afEM1e
# NwjCXaRcLoDCkqxkeOTbfMgEBVXY6ERp/s5PrWP4/vW7ixUSzngKDkIhKFB1YADs
# ShB2P9u4MNTizKlHsuumqPuh4aS0G9MqZXv1fSNY3DgrxEjy0AazCqx7pjaHNyal
# /oYBXCvxtjx8JvEavaP0X/zzchW9L61Ca9itBC9ahwiL7nROmu3700MmnT3VwnX1
# tqwyDC6yT6AzfyfDiL5CTzGYr+7myiWJvvvcka0/n+V6osJgGubu7hUm+rrdvToF
# sBzKCWsdYdv/QJzTc14reqGCF5YwgheSBgorBgEEAYI3AwMBMYIXgjCCF34GCSqG
# SIb3DQEHAqCCF28wghdrAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFRBgsqhkiG9w0B
# CRABBKCCAUAEggE8MIIBOAIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFlAwQCAQUA
# BCA5A7rDjnaULDcyiaQYAlrcIEIwxO5YJ3vcKoQVuP7MHQIGaBpnHQJQGBIyMDI1
# MDUwOTExMjEwNS42OFowBIACAfSggdGkgc4wgcsxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9w
# ZXJhdGlvbnMxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVTTjozNzAzLTA1RTAtRDk0
# NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaCCEe0wggcg
# MIIFCKADAgECAhMzAAACCkeyFNnusrMPAAEAAAIKMA0GCSqGSIb3DQEBCwUAMHwx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1p
# Y3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTI1MDEzMDE5NDI1N1oXDTI2
# MDQyMjE5NDI1N1owgcsxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlvbnMxJzAlBgNV
# BAsTHm5TaGllbGQgVFNTIEVTTjozNzAzLTA1RTAtRDk0NzElMCMGA1UEAxMcTWlj
# cm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCCAiIwDQYJKoZIhvcNAQEBBQADggIP
# ADCCAgoCggIBALLs3PASlvsGnACT0snTRerfRNxONzA1nzRPEC0BuFJonaTCckDU
# C78Oj398QGMAe/oya23d+Y8N4gmdDtUF4irxFx+NyOts8iDfADm/kxB+U81IE069
# xdE/59mcDLQQsPN+ckecKRk2xBRnsYXsvFQtMo5hjZgnDhOuZweiGRjoOMJnLGGq
# YZDDB1uOg9ZFti7+jMV6b/J8k/KNUGqXXTrxtxWHnwDxzkIPpNY38ve743L7s7z4
# O96vqoFPjgTLul89kxnUeLvK8Iu/ksbNIHqjY4PkYhnLvPiSHxRgd3OOf1bH5Bnb
# bfdIlAq1mGkju4d/egxODTNqdB/PuaC515+YYGtASDWjHef7dOLOHQP3NWY1A/2w
# WOw9C00Zn0gP0fwD6QUifHiatLEDZLIYw5BzGUYzfSS0gozeKoK4URT0IdUyk33j
# /V+XhPo+icn7+hYmoWVq1i4wq/Zny6KmucVwDEKk6wMhUE70rW8d4AyJBBSVwT0I
# PnfojVgueY7aodqA8+ZeF04asdScJS2inbV6W6QeHvmr/nMf46c16Snm52mNA1kK
# +JgBl0ewueRTQ19QCvqvVSoNxKrXJ/lGLCKYHxKOx2YeWXiA+OapWLT+uaczWgAR
# Cbc/JZxNBCJtguK4o3tjiKjlslNXCb69FFuknlQv8PfcL//uqcdt6hYFAgMBAAGj
# ggFJMIIBRTAdBgNVHQ4EFgQUAq8XQQSPgDI99jxb+quwC9+1nCQwHwYDVR0jBBgw
# FoAUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXwYDVR0fBFgwVjBUoFKgUIZOaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jcmwvTWljcm9zb2Z0JTIwVGltZS1T
# dGFtcCUyMFBDQSUyMDIwMTAoMSkuY3JsMGwGCCsGAQUFBwEBBGAwXjBcBggrBgEF
# BQcwAoZQaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNy
# b3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcnQwDAYDVR0TAQH/
# BAIwADAWBgNVHSUBAf8EDDAKBggrBgEFBQcDCDAOBgNVHQ8BAf8EBAMCB4AwDQYJ
# KoZIhvcNAQELBQADggIBALCTc9bQLKM5qpcIw66xN17t6nYLA//FXUnej0oCIpJ2
# rxrZRHlEIdiGcmx56bB4xQfaQ15+mcCHYGfwfaikPO0MmSPw5hF38pDKwTXY3Bpj
# co7ABbxGDw51e/l9Rkiw5aCmuQJAzRWgUd1dgTGQk3cTMFtQJTDfJviAAU8rnpP7
# pw+kjwwkskJBcc0yC2LZBmFf0qR9EB98VgwVymxsj6jOILkGuuTffrVwkUeGAQlH
# QnjaeplMZKBSkMYdJkBEao1wBXmH45AMt4XandRHH8/oxxSDWcnaAw9gGwP5vB30
# HRz9chn0y3e6OUQs+mSKOMJ1JnGHO7YzdJlYmvnu5j4UL4uym8g4fU6mh9qeHckY
# Oiw1wAS73JQxYqwQEyeAPpVZBJBhnpf0XzTMKh5nBOrSL0C6OdjPPHlbZ8SBl6NG
# 7orUYIBKbO02VgmUAKOpp9ZGh9OqQmFX8na/3tfeu4O9+m465ChS1UDBesOwbY04
# G69Wyjkp1bniEFKzP/j45EHiouerj8Y21qNQeispEocY6AWjwMppcb5Q0A3CEY3E
# dsgtJrn0/ETEyAKMFE/fzbzIYqyq5ITPMs1afPlp/1mZ4fjzT1/Ai20jjUmS6Jj1
# fqGYyYti/w5jfi+84r7PLGRL70FQtUA/qC37JodoGWuWfwaLj90GvbLpKuv/nqDQ
# MIIHcTCCBVmgAwIBAgITMwAAABXF52ueAptJmQAAAAAAFTANBgkqhkiG9w0BAQsF
# ADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UE
# AxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcN
# MjEwOTMwMTgyMjI1WhcNMzAwOTMwMTgzMjI1WjB8MQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFt
# cCBQQ0EgMjAxMDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAOThpkzn
# tHIhC3miy9ckeb0O1YLT/e6cBwfSqWxOdcjKNVf2AX9sSuDivbk+F2Az/1xPx2b3
# lVNxWuJ+Slr+uDZnhUYjDLWNE893MsAQGOhgfWpSg0S3po5GawcU88V29YZQ3MFE
# yHFcUTE3oAo4bo3t1w/YJlN8OWECesSq/XJprx2rrPY2vjUmZNqYO7oaezOtgFt+
# jBAcnVL+tuhiJdxqD89d9P6OU8/W7IVWTe/dvI2k45GPsjksUZzpcGkNyjYtcI4x
# yDUoveO0hyTD4MmPfrVUj9z6BVWYbWg7mka97aSueik3rMvrg0XnRm7KMtXAhjBc
# TyziYrLNueKNiOSWrAFKu75xqRdbZ2De+JKRHh09/SDPc31BmkZ1zcRfNN0Sidb9
# pSB9fvzZnkXftnIv231fgLrbqn427DZM9ituqBJR6L8FA6PRc6ZNN3SUHDSCD/AQ
# 8rdHGO2n6Jl8P0zbr17C89XYcz1DTsEzOUyOArxCaC4Q6oRRRuLRvWoYWmEBc8pn
# ol7XKHYC4jMYctenIPDC+hIK12NvDMk2ZItboKaDIV1fMHSRlJTYuVD5C4lh8zYG
# NRiER9vcG9H9stQcxWv2XFJRXRLbJbqvUAV6bMURHXLvjflSxIUXk8A8FdsaN8cI
# FRg/eKtFtvUeh17aj54WcmnGrnu3tz5q4i6tAgMBAAGjggHdMIIB2TASBgkrBgEE
# AYI3FQEEBQIDAQABMCMGCSsGAQQBgjcVAgQWBBQqp1L+ZMSavoKRPEY1Kc8Q/y8E
# 7jAdBgNVHQ4EFgQUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXAYDVR0gBFUwUzBRBgwr
# BgEEAYI3TIN9AQEwQTA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9Eb2NzL1JlcG9zaXRvcnkuaHRtMBMGA1UdJQQMMAoGCCsGAQUF
# BwMIMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNV
# HRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYG
# A1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3Js
# L3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcB
# AQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kv
# Y2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MA0GCSqGSIb3DQEBCwUA
# A4ICAQCdVX38Kq3hLB9nATEkW+Geckv8qW/qXBS2Pk5HZHixBpOXPTEztTnXwnE2
# P9pkbHzQdTltuw8x5MKP+2zRoZQYIu7pZmc6U03dmLq2HnjYNi6cqYJWAAOwBb6J
# 6Gngugnue99qb74py27YP0h1AdkY3m2CDPVtI1TkeFN1JFe53Z/zjj3G82jfZfak
# Vqr3lbYoVSfQJL1AoL8ZthISEV09J+BAljis9/kpicO8F7BUhUKz/AyeixmJ5/AL
# aoHCgRlCGVJ1ijbCHcNhcy4sa3tuPywJeBTpkbKpW99Jo3QMvOyRgNI95ko+ZjtP
# u4b6MhrZlvSP9pEB9s7GdP32THJvEKt1MMU0sHrYUP4KWN1APMdUbZ1jdEgssU5H
# LcEUBHG/ZPkkvnNtyo4JvbMBV0lUZNlz138eW0QBjloZkWsNn6Qo3GcZKCS6OEua
# bvshVGtqRRFHqfG3rsjoiV5PndLQTHa1V1QJsWkBRH58oWFsc/4Ku+xBZj1p/cvB
# QUl+fpO+y/g75LcVv7TOPqUxUYS8vwLBgqJ7Fx0ViY1w/ue10CgaiQuPNtq6TPmb
# /wrpNPgkNWcr4A245oyZ1uEi6vAnQj0llOZ0dFtq0Z4+7X6gMTN9vMvpe784cETR
# kPHIqzqKOghif9lwY1NNje6CbaUFEMFxBmoQtB1VM1izoXBm8qGCA1AwggI4AgEB
# MIH5oYHRpIHOMIHLMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQ
# MA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9u
# MSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMScwJQYDVQQL
# Ex5uU2hpZWxkIFRTUyBFU046MzcwMy0wNUUwLUQ5NDcxJTAjBgNVBAMTHE1pY3Jv
# c29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiIwoBATAHBgUrDgMCGgMVANEAxUmUDpsq
# r3dWe7dSQmCbkeVhoIGDMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIw
# MTAwDQYJKoZIhvcNAQELBQACBQDryDEjMCIYDzIwMjUwNTA5MDc0NTM5WhgPMjAy
# NTA1MTAwNzQ1MzlaMHcwPQYKKwYBBAGEWQoEATEvMC0wCgIFAOvIMSMCAQAwCgIB
# AAICCQwCAf8wBwIBAAICErowCgIFAOvJgqMCAQAwNgYKKwYBBAGEWQoEAjEoMCYw
# DAYKKwYBBAGEWQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGGoDANBgkqhkiG9w0B
# AQsFAAOCAQEAbNRwObQJgnKz27GTkVK1gr/zjJXr89UDbqd2+bBu07VZYZ447X38
# WHQbs1t5hEr/R6802o+VZ6pooZkjeEI1Xf2iPLHvlrAgONjEsd2FK/pgJAz5QfnC
# ovPiCMC0n7QE7l+hTpvH000HT79ByjVYMBlYPWRUgK+DkQyg0I0v0EL0RdI9HSLA
# nYPoCMDjmD/bupIE/Xoa3zfU9GZFNSU3cZ6MrlToovludcamd8sHG0bwoQiTv4tw
# 0o7DmKVcppGhhGVoHpXAIDmvrwbSc9qlHcj0qPIxNRsyCW4CmbCwo3xcmMBK2fql
# J+UBaBFFY/Iz891qC/kRgfS92cGW942SlTGCBA0wggQJAgEBMIGTMHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAACCkeyFNnusrMPAAEAAAIKMA0GCWCG
# SAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQwLwYJKoZI
# hvcNAQkEMSIEIEwuW1Wm1QEtSPnxQRUmA7oFckOIZfeLm07gJzE1RB0BMIH6Bgsq
# hkiG9w0BCRACLzGB6jCB5zCB5DCBvQQgTZrL/LR6kr9fdnTcpNyWioTy70hdG107
# sx7HSHD35JowgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAIT
# MwAAAgpHshTZ7rKzDwABAAACCjAiBCDJUnSETjsVz4Lt97iFH+ib4Ei+mr6+iiKZ
# qpYHeqKF5DANBgkqhkiG9w0BAQsFAASCAgBt+fwMjnualkz1pxBjGgx7G2X1ucJk
# nGgnwoVERW38zaq4DAZ677g8x+pVCNP2ypf1CKbrQwNDpyIvWHyoFDd7t/0UazDv
# A/dBO1bd1ZClDiqMZXXGQCuWq+sDWcDcDDscMjUeDAuzVWahdDNQIJYRFqLyVR/t
# jseVkAiIQ0I0W7YYHoOia+wvh+E+79G8HKbM79nME2gTxU1rw+UGoMXcAfCIcstd
# hPMFrCu3N6xRL/2EpyvNUH1FuFUo+ATYBaqwgXEe+4rSXjzvIeLl/ZYSXAVJ7sOn
# OJmmWiECSvkIpRm2ZQhz/vFXRXYmRzJtPzf0GSgXBwJnzuxCxF0HrRPrPrvpe2pC
# 1FShLILj9/i3xehr9d3Y/NY+pIXjUIgbLyuZAs1P5Oukzf7mk2kANzAtagTe0AxY
# G0BB3wPJ8fQCUFUC0wRAImSBZBJ+BWMHjtzOQqDEDqRMIg0PgoKDaZiheQuNtce8
# J7r16jPoe0lWxs07xDTFArg/fanxw801dRvolZ/GzghpmPWbp0xYnadv/yHV4ick
# bGS+OJhFIXhmi9Fiw8l6ObZqe3cEzU2kMnUJolmaVD4l+LMW6MtrdAI2nONT8Fhm
# K9X6jSvmV3UMyEoJHl2wAJBpt1iZc/QiPR83DKDle0F9QRwRP6kQu8ypczkz/H+5
# rgkAER6HH7xJQg==
# SIG # End signature block
